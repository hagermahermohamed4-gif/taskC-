﻿using Day02ASP.NETMCV.Models;
using System.Collections.Generic;

namespace Day02ASP.NETMCV.ViewModels
{
    public class DepartmentStudentFilterViewModel
    {
        public string DepartmentName { get; set; }
        public string DepartmentState { get; set; }
        public List<Student> StudentsAbove25 { get; set; } = new List<Student>();
    }
}