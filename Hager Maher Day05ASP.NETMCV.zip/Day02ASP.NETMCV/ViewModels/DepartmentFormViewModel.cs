﻿using System.ComponentModel.DataAnnotations;

namespace Day02ASP.NETMCV.ViewModels
{
    public class DepartmentFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "اسم القسم مطلوب")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "اسم القسم يجب أن يكون بين حرفين و 50 حرف")]
        [Display(Name = "اسم القسم")]
        public string Name { get; set; }
    }
}