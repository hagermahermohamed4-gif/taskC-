﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Day02ASP.NETMCV.ViewModels
{
    public class StudentFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "اسم الطالب مطلوب")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "الاسم يجب أن يكون بين 3 و 50 حرف")]
        [Display(Name = "اسم الطالب")]
        public string Name { get; set; }

        [Required(ErrorMessage = "العمر مطلوب")]
        [Range(18, 60, ErrorMessage = "العمر يجب أن يكون بين 18 و 60 سنة")]
        [Display(Name = "العمر")]
        public int Age { get; set; }

        [Required(ErrorMessage = "يرجى اختيار القسم")]
        [Display(Name = "القسم")]
        public int DepartmentId { get; set; }

        // القائمة المنسدلة للقسم باستعمال asp-items
        public IEnumerable<SelectListItem> Departments { get; set; } = new List<SelectListItem>();
    }
}