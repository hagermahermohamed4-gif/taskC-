﻿using Day02ASP.NETMCV.Contexts;
using Day02ASP.NETMCV.Models;
using Day02ASP.NETMCV.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Day02ASP.NETMCV.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ITIDbContext _context;

        public DepartmentController(ITIDbContext context)
        {
            _context = context;
        }

        // ShowAll
        public async Task<IActionResult> ShowAll()
        {
            var departments = await _context.Departments.Include(d => d.Students).ToListAsync();
            return View(departments);
        }

        // Add (GET)
        [HttpGet]
        public IActionResult Add()
        {
            return View(new DepartmentFormViewModel());
        }

        // Add (POST - Validated)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(DepartmentFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var department = new Department
            {
                Name = model.Name
            };

            _context.Departments.Add(department);
            await _context.SaveChangesAsync();
            return RedirectToAction("ShowAll");
        }

        // Edit (GET)
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var department = await _context.Departments.FindAsync(id);
            if (department == null) return NotFound();

            var model = new DepartmentFormViewModel
            {
                Id = department.Id,
                Name = department.Name
            };

            return View(model);
        }

        // Edit (POST - Validated)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, DepartmentFormViewModel model)
        {
            if (id != model.Id) return BadRequest();

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var department = await _context.Departments.FindAsync(id);
            if (department == null) return NotFound();

            department.Name = model.Name;
            _context.Update(department);
            await _context.SaveChangesAsync();

            return RedirectToAction("ShowAll");
        }
    }
}