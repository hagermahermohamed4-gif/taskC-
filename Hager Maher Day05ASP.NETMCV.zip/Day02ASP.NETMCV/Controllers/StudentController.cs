﻿using Day02ASP.NETMCV.Contexts;
using Day02ASP.NETMCV.Models;
using Day02ASP.NETMCV.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day02ASP.NETMCV.Controllers
{
    public class StudentController : Controller
    {
        private readonly ITIDbContext _context;

        public StudentController(ITIDbContext context)
        {
            _context = context;
        }

        // 1. GetAll (Search, Filter & Pagination)
        public async Task<IActionResult> ShowAll(string searchName, int? selectedDeptId, int pageNumber = 1)
        {
            int pageSize = 3;
            var query = _context.Students.Include(s => s.Department).AsQueryable();

            if (!string.IsNullOrEmpty(searchName))
            {
                query = query.Where(s => s.Name.Contains(searchName));
            }

            if (selectedDeptId.HasValue && selectedDeptId.Value > 0)
            {
                query = query.Where(s => s.DepartmentId == selectedDeptId.Value);
            }

            int totalItems = await query.CountAsync();
            int totalPages = (int)Math.Ceiling(totalItems / (double)pageSize);

            var students = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var viewModel = new StudentListViewModel
            {
                Students = students,
                SearchName = searchName,
                SelectedDeptId = selectedDeptId,
                CurrentPage = pageNumber,
                TotalPages = totalPages,
                Departments = await _context.Departments
                    .Select(d => new SelectListItem { Value = d.Id.ToString(), Text = d.Name })
                    .ToListAsync()
            };

            return View(viewModel);
        }

        // 2. ShowDetails
        public async Task<IActionResult> ShowDetails(int id)
        {
            var student = await _context.Students
                .Include(s => s.Department)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (student == null) return NotFound();

            return View(student);
        }

        // 3. Add (GET)
        [HttpGet]
        public async Task<IActionResult> Add()
        {
            var viewModel = new StudentFormViewModel
            {
                Departments = await GetDepartmentSelectListAsync()
            };
            return View(viewModel);
        }

        // 3. Add (POST - Validated)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(StudentFormViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.Departments = await GetDepartmentSelectListAsync();
                return View(model);
            }

            var student = new Student
            {
                Name = model.Name,
                Age = model.Age,
                DepartmentId = model.DepartmentId
            };

            _context.Students.Add(student);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowAll));
        }

        // 4. Edit (GET)
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            var viewModel = new StudentFormViewModel
            {
                Id = student.Id,
                Name = student.Name,
                Age = student.Age,
                DepartmentId = student.DepartmentId,
                Departments = await GetDepartmentSelectListAsync()
            };

            return View(viewModel);
        }

        // 4. Edit (POST - Validated)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, StudentFormViewModel model)
        {
            if (id != model.Id) return BadRequest();

            if (!ModelState.IsValid)
            {
                model.Departments = await GetDepartmentSelectListAsync();
                return View(model);
            }

            var student = await _context.Students.FindAsync(id);
            if (student == null) return NotFound();

            student.Name = model.Name;
            student.Age = model.Age;
            student.DepartmentId = model.DepartmentId;

            _context.Update(student);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowAll));
        }

        // 5. Delete (GET Warning)
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var student = await _context.Students
                .Include(s => s.Department)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (student == null) return NotFound();

            return View("DeleteWarning", student);
        }

        // 5. Delete (POST Confirmation)
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var student = await _context.Students.FindAsync(id);
            if (student != null)
            {
                _context.Students.Remove(student);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(ShowAll));
        }

        private async Task<IEnumerable<SelectListItem>> GetDepartmentSelectListAsync()
        {
            return await _context.Departments
                .Select(d => new SelectListItem
                {
                    Value = d.Id.ToString(),
                    Text = d.Name
                }).ToListAsync();
        }
    }
}