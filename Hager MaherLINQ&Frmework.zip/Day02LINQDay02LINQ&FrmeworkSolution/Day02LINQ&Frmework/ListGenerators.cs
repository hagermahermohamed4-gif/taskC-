﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace day10_G01
{
    class Product : IComparable<Product>
    {
        public long ProductID { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public decimal UnitPrice { get; set; }
        public int UnitsInStock { get; set; }

        public int CompareTo(Product other)
        => this.UnitPrice.CompareTo(other.UnitPrice);

        public override string ToString()
            => $"ProductID:{ProductID},ProductName:{ProductName},Category{Category},UnitPrice:{UnitPrice},UnitsInStock:{UnitsInStock}";
    }

    class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public Order[] Orders { get; set; }

        public Customer(int customerID, string customerName)
        {
            Id = customerID;
            Name = customerName;
            Orders = new Order[10];
        }

        public Customer() { }

        public override string ToString()
            => $"{Id}, {Name}, {Address}, {City}, {City}, {PostalCode}, {Country}, {Phone}, {Fax}";
    }

    class Order
    {
        public int Id { get; set; }
        public DateTime OrderDate { get; set; }
        public double Total { get; set; }

        public Order(int orderID, DateTime orderDate, double total)
        {
            Id = orderID;
            OrderDate = orderDate;
            Total = total;
        }

        public Order() { }

        public override string ToString()
            => $"Order Id: {Id}, Date: {OrderDate.ToShortDateString()}, Total: {Total}";
    }

    internal static class ListGenerators
    {
        public static List<Product> ProductList { get; set; }
        public static List<Customer> CustomerList { get; set; }

        static ListGenerators()
        {
            ProductList = new List<Product>()
            {
              new Product {ProductID = 1, ProductName = "Chai", Category = "Beverages", UnitPrice = 18.00M, UnitsInStock = 100},
              new Product {ProductID = 2, ProductName = "Chang", Category = "Beverages", UnitPrice = 19.0000M, UnitsInStock = 17},
              new Product {ProductID = 3, ProductName = "Aniseed Syrup", Category = "Condiments", UnitPrice = 10.0000M, UnitsInStock = 13},
              new Product {ProductID = 4, ProductName = "Chef Anton's Cajun Seasoning", Category = "Condiments", UnitPrice = 22.0000M, UnitsInStock = 53},
              new Product {ProductID = 5, ProductName = "Chef Anton's Gumbo Mix", Category = "Condiments", UnitPrice = 21.3500M, UnitsInStock = 0},
              new Product {ProductID = 6, ProductName = "Grandma's Boysenberry Spread", Category = "Condiments", UnitPrice = 25.0000M, UnitsInStock = 120},
              new Product {ProductID = 7, ProductName = "Uncle Bob's Organic Dried Pears", Category = "Produce", UnitPrice = 30.0000M, UnitsInStock = 15},
              new Product {ProductID = 8, ProductName = "Northwoods Cranberry Sauce", Category = "Condiments", UnitPrice = 40.0000M, UnitsInStock = 6},
              new Product {ProductID = 9, ProductName = "Mishi Kobe Niku", Category = "Meat/Poultry", UnitPrice = 97.0000M, UnitsInStock = 29},
              new Product {ProductID = 10, ProductName = "Ikura", Category = "Seafood", UnitPrice = 31.0000M, UnitsInStock = 31}
            };

            CustomerList = new List<Customer>()
            {
                new Customer
                {
                    Id = 212,
                    Name = "Ahmed Ali",
                    Address = "Obere Str. 57",
                    City = "Berlin",
                    PostalCode = "12209",
                    Country = "Germany",
                    Phone = "030-0074321",
                    Fax = "030-0076545",
                    Orders = new Order[]
                    {
                        new Order { Id = 10643, OrderDate = new DateTime(1997, 8, 25), Total = 814.50 },
                        new Order { Id = 10692, OrderDate = new DateTime(1997, 10, 3), Total = 878.00 },
                        new Order { Id = 10702, OrderDate = new DateTime(1997, 10, 13), Total = 330.00 }
                    }
                }
            };
        }
    }
}