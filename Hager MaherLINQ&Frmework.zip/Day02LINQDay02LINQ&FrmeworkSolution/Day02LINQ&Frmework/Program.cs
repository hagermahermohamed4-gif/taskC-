﻿using System;
using System.Collections.Generic;
using System.Linq;
using day10_G01;
using static day10_G01.ListGenerators;

namespace Day02LINQ_Frmework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Set Operators
            // 1. Find the unique Category names from ProductList
            var set1 = ProductList.Select(p => p.Category).Distinct();
            Console.WriteLine("--- Unique Categories ---");
            foreach (var item in set1)
            {
                Console.WriteLine(item);
            }

            // 2. Produce a sequence containing the unique first letters from both product and customer names
            var prodFirstChars = ProductList.Select(p => p.ProductName[0]);
            var custFirstChars = CustomerList.Select(c => c.Name[0]);

            var set2 = prodFirstChars.Union(custFirstChars);
            Console.WriteLine("\n--- Union of First Letters ---");
            foreach (var ch in set2)
            {
                Console.WriteLine(ch);
            }

            // 3. Create one sequence that Contains the common first letters from both product and customer names
            var set3 = prodFirstChars.Intersect(custFirstChars);
            Console.WriteLine("\n--- Common First Letters ---");
            foreach (var ch in set3)
            {
                Console.WriteLine(ch);
            }

            // 4. Create one sequence that Contains the first letters of product names that are not also first letters of customer names
            var set4 = prodFirstChars.Except(custFirstChars);
            Console.WriteLine("\n--- Product First Letters Except Customer ---");
            foreach (var ch in set4)
            {
                Console.WriteLine(ch);
            }
            #endregion

            #region Partitioning Operators
            // 1. Get the first 3 orders from customers in Berlin
            var part1 = CustomerList.Where(c => c.City == "Berlin")
                .SelectMany(c => c.Orders)
                .Take(3);
            Console.WriteLine("\n--- First 3 Orders from Berlin ---");
            foreach (var o in part1)
            {
                Console.WriteLine(o.Id);
            }

            // 2. Get all but the first 2 orders from customers in Berlin
            var part2 = CustomerList.Where(c => c.City == "Berlin")
                .SelectMany(c => c.Orders)
                .Skip(2);
            Console.WriteLine("\n--- All Except First 2 Orders from Berlin ---");
            foreach (var o in part2)
            {
                Console.WriteLine(o.Id);
            }

            int[] numbersP = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

            // 3. Return elements until a number is hit that is less than its position
            var part3 = numbersP.TakeWhile((n, index) => n >= index);
            Console.WriteLine("\n--- TakeWhile Number >= Index ---");
            foreach (var n in part3)
            {
                Console.WriteLine(n);
            }

            // 4. Get the elements starting from the first element divisible by 3
            var part4 = numbersP.SkipWhile(n => n % 3 != 0);
            Console.WriteLine("\n--- SkipWhile Not Divisible by 3 ---");
            foreach (var n in part4)
            {
                Console.WriteLine(n);
            }

            // 5. Get elements starting from the first element less than its position
            var part5 = numbersP.SkipWhile((n, index) => n >= index);
            Console.WriteLine("\n--- SkipWhile Number >= Index ---");
            foreach (var n in part5)
            {
                Console.WriteLine(n);
            }
            #endregion

            #region Quantifiers
            // 2. Categories that have at least one product out of stock
            var q1 = ProductList.GroupBy(p => p.Category)
                .Where(g => g.Any(p => p.UnitsInStock == 0));
            Console.WriteLine("\n--- Categories with at Least One Out of Stock ---");
            foreach (var g in q1)
            {
                Console.WriteLine(g.Key);
            }

            // 3. Categories that have all of their products in stock
            var q2 = ProductList.GroupBy(p => p.Category)
                .Where(g => g.All(p => p.UnitsInStock > 0));
            Console.WriteLine("\n--- Categories with All Products In Stock ---");
            foreach (var g in q2)
            {
                Console.WriteLine(g.Key);
            }
            #endregion

            #region Grouping Operators
            // 1. Group numbers by their remainder when divided by 5
            List<int> numbersG = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
            var g1 = numbersG.GroupBy(n => n % 5);
            Console.WriteLine("\n--- Numbers Grouped by Remainder (mod 5) ---");
            foreach (var group in g1)
            {
                Console.WriteLine(string.Format("Numbers with remainder {0}:", group.Key));
                foreach (var n in group)
                {
                    Console.WriteLine(n);
                }
            }

            // 2. Group words by their first letter
            string[] wordsG = { "apple", "banana", "apricot", "blueberry", "cherry" };
            var g2 = wordsG.GroupBy(w => w[0]);
            Console.WriteLine("\n--- Words Grouped by First Letter ---");
            foreach (var group in g2)
            {
                Console.WriteLine(string.Format("Words starting with {0}:", group.Key));
                foreach (var w in group)
                {
                    Console.WriteLine(w);
                }
            }

            // 3. Group products by Category
            var g3 = ProductList.GroupBy(p => p.Category);
            Console.WriteLine("\n--- Products Grouped by Category ---");
            foreach (var group in g3)
            {
                Console.WriteLine(string.Format("Category: {0}", group.Key));
                foreach (var prod in group)
                {
                    Console.WriteLine(prod.ProductName);
                }
            }
            #endregion
        }
    }
}