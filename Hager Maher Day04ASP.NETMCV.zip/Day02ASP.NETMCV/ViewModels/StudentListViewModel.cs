﻿using Day02ASP.NETMCV.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace Day02ASP.NETMCV.ViewModels
{
    public class StudentListViewModel
    {
        public IEnumerable<Student> Students { get; set; }

        // خيارات البحث والفلترة
        public string SearchName { get; set; }
        public int? SelectedDeptId { get; set; }
        public IEnumerable<SelectListItem> Departments { get; set; }

        // خيارات الـ Pagination
        public int CurrentPage { get; set; } = 1;
        public int TotalPages { get; set; }
        public int PageSize { get; set; } = 3; // عدد العناصر في الصفحة
    }
}