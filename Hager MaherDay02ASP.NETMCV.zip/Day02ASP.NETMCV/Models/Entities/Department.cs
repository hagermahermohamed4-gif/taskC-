﻿using System.Collections.Generic;

namespace Day02ASP.NETMCV.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string MgrName { get; set; }

        public ICollection<Teacher> Teachers { get; set; } = new HashSet<Teacher>();
        public ICollection<Course> Courses { get; set; } = new HashSet<Course>();
        public ICollection<Student> Students { get; set; } = new HashSet<Student>();
    }
}