﻿using System.Collections.Generic;

namespace Day02ASP.NETMCV.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Degree { get; set; }
        public int MinDegree { get; set; }

        public int DepartmentId { get; set; }
        public Department Department { get; set; }

        public ICollection<Teacher> Teachers { get; set; } = new HashSet<Teacher>();
        public ICollection<StuCrsRes> StuCrsRes { get; set; } = new HashSet<StuCrsRes>();
    }
}