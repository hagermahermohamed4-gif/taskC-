﻿ using Day02ASP.NETMCV.Contexts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Day02ASP.NETMCV.Controllers
{
    public class StudentController : Controller
    {
        private readonly ITIDbContext _context;

        public StudentController(ITIDbContext context)
        {
            _context = context;
        }

        // GET: /Student/ShowAll
        public IActionResult ShowAll()
        {
            var students = _context.Students.Include(s => s.Department).ToList();
            return View(students);
        }

        // GET: /Student/ShowDetails?id=3
        public IActionResult ShowDetails(int id)
        {
            var student = _context.Students
                .Include(s => s.Department)
                .FirstOrDefault(s => s.Id == id);

            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }
    }
}