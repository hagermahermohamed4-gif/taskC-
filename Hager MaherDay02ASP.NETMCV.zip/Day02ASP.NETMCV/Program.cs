using Day02ASP.NETMCV.Contexts;
using Day02ASP.NETMCV.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register DbContext with SQL Server Connection String
builder.Services.AddDbContext<ITIDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Seed Initial Data (Department & Student) if Database is empty
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ITIDbContext>();

    // Ensure database is created
    context.Database.Migrate();

    if (!context.Departments.Any())
    {
        var dept = new Department { Name = "Computer Science", MgrName = "Dr. Ahmed" };
        context.Departments.Add(dept);
        context.SaveChanges();

        
        context.Students.AddRange(
            new Student { Name = "Hager", Age = 21, DepartmentId = dept.Id },
            new Student { Name = "Mohamed", Age = 22, DepartmentId = dept.Id },
            new Student { Name = "Ahmed", Age = 20, DepartmentId = dept.Id },
            new Student { Name = "Sara", Age = 21, DepartmentId = dept.Id },
            new Student { Name = "Mona", Age = 23, DepartmentId = dept.Id },
            new Student { Name = "Omar", Age = 22, DepartmentId = dept.Id }
        );

        context.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();