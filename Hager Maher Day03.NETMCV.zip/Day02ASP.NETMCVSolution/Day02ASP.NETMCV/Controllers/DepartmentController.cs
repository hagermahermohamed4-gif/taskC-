﻿using Day02ASP.NETMCV.Contexts;
using Day02ASP.NETMCV.Models;
using Day02ASP.NETMCV.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Day02ASP.NETMCV.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ITIDbContext _context;

        // Dependency Injection
        public DepartmentController(ITIDbContext context)
        {
            _context = context;
        }

        // 1. ShowAll LifeCycle
        public IActionResult ShowAll()
        {
            var departments = _context.Departments
                .Include(d => d.Students)
                .ToList();

            return View(departments);
        }

        // 2. ShowDetails LifeCycle
        public IActionResult ShowDetails(int id)
        {
            var department = _context.Departments
                .Include(d => d.Students)
                .FirstOrDefault(d => d.Id == id);

            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // 3. Add LifeCycle (GET)
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        // 3. Add LifeCycle (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(Department department)
        {
            if (ModelState.IsValid)
            {
                _context.Departments.Add(department);
                _context.SaveChanges();
                return RedirectToAction(nameof(ShowAll));
            }

            return View(department);
        }

        // 4. Department Details with ViewModel (Requirement 2)
        public IActionResult DepartmentDetailsVM(int id)
        {
            var department = _context.Departments
                .Include(d => d.Students)
                .FirstOrDefault(d => d.Id == id);

            if (department == null)
            {
                return NotFound();
            }

            var viewModel = new DepartmentStudentFilterViewModel
            {
                DepartmentName = department.Name,
                DepartmentState = department.Students.Count > 50 ? "Main" : "Branch",
                StudentsAbove25 = department.Students
                    .Where(s => s.Age > 25)
                    .Select(s => s.Name)
                    .ToList()
            };

            return View(viewModel);
        }
    }
}