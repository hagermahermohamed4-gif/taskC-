﻿using System.Collections.Generic;

namespace Day02ASP.NETMCV.ViewModels
{
    public class DepartmentStudentFilterViewModel
    {
        public string DepartmentName { get; set; }
        public string DepartmentState { get; set; } // "Main" if > 50 students, else "Branch"
        public List<string> StudentsAbove25 { get; set; } = new List<string>();
    }
}