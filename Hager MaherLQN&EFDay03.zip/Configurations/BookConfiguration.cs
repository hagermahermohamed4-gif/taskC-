﻿using Day03LQN_EF.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Day03LQN_EF.Configurations
{
    public class BookConfiguration : IEntityTypeConfiguration<Book>
    {
        public void Configure(EntityTypeBuilder<Book> builder)
        {
            builder.Property(b => b.Title)
                   .IsRequired()
                   .HasMaxLength(150);

            builder.Property(b => b.Price)
                   .HasColumnType("decimal(8,2)")
                   .IsRequired();

            builder.Property(b => b.PublishedDate)
                   .IsRequired(false);
        }
    }
}