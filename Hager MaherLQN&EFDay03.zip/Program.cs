﻿using System;
using System.Linq;
using Day03LQN_EF.Contexts;
using Day03LQN_EF.Models;

namespace Day03LQN_EF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var context = new BookstoreDbContext())
            {
                // Add test author
                var author = new Author { Name = "Clean Code Author", Country = "Egypt" };
                context.Authors.Add(author);

                // Add test book
                var book = new Book
                {
                    Title = "Entity Framework Core Guide",
                    Price = 250.00m,
                    PublishedDate = DateTime.Now
                };
                context.Books.Add(book);

                // Save changes to Database
                context.SaveChanges();
                Console.WriteLine("Data Saved Successfully!");

                // Retrieve and display books
                Console.WriteLine("\n--- Books List ---");
                foreach (var b in context.Books)
                {
                    Console.WriteLine($"ID: {b.Id} | Title: {b.Title} | Price: {b.Price} EGP");
                }
            }
        }
    }
}