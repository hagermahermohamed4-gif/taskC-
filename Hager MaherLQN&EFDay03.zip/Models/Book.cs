﻿using System;

namespace Day03LQN_EF.Models
{
    /*
     * Q1: Why did the property "Id" become a Primary Key without any explicit configuration?
     * Answer: By EF Core Convention, any property named 'Id' or '<EntityName>Id' 
     * is automatically configured as the Primary Key and an Identity column.
     *
     * Q2: Why is "Country" nullable in the database while "Price" is not?
     * Answer: 'Price' is a non-nullable C# value type (decimal), so EF Core maps it as NOT NULL.
     * 'Country' is a reference/nullable string type, so EF Core maps it as NULLABLE by default.
     */
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public decimal Price { get; set; }
        public DateTime? PublishedDate { get; set; }
    }
}