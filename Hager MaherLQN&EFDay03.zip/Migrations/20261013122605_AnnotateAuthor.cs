﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Day03LQN_EF.Migrations
{
    public partial class AnnotateAuthor : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
