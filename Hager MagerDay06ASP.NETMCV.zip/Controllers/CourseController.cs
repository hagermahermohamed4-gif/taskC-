﻿using Day02ASP.NETMCV.Contexts;
using Day02ASP.NETMCV.Models;
using Day02ASP.NETMCV.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day02ASP.NETMCV.Controllers
{
    public class CourseController : Controller
    {
        private readonly ITIDbContext _context;

        public CourseController(ITIDbContext context)
        {
            _context = context;
        }

        // 1. Read All
        public async Task<IActionResult> ShowAll()
        {
            var courses = await _context.Courses.Include(c => c.Department).ToListAsync();
            return View(courses);
        }

        // 2. Create (GET)
        [HttpGet]
        public async Task<IActionResult> Add()
        {
            var model = new CourseFormViewModel
            {
                Departments = await GetDepartmentsAsync()
            };
            return View(model);
        }

        // 2. Create (POST + Server-Side Validation)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(CourseFormViewModel model)
        {
            if (model.MinDegree >= model.Degree)
            {
                ModelState.AddModelError("MinDegree", "Minimum degree must be less than the total degree.");
            }

            if (!ModelState.IsValid)
            {
                model.Departments = await GetDepartmentsAsync();
                return View(model);
            }

            var course = new Course
            {
                Name = model.Name,
                Degree = model.Degree,
                MinDegree = model.MinDegree,
                DepartmentId = model.DepartmentId
            };

            _context.Courses.Add(course);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowAll));
        }

        // 3. Update (GET)
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course == null) return NotFound();

            var model = new CourseFormViewModel
            {
                Id = course.Id,
                Name = course.Name,
                Degree = course.Degree,
                MinDegree = course.MinDegree,
                DepartmentId = course.DepartmentId,
                Departments = await GetDepartmentsAsync()
            };

            return View(model);
        }

        // 3. Update (POST + Server-Side Validation)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CourseFormViewModel model)
        {
            if (id != model.Id) return BadRequest();

            if (model.MinDegree >= model.Degree)
            {
                ModelState.AddModelError("MinDegree", "Minimum degree must be less than the total degree.");
            }

            if (!ModelState.IsValid)
            {
                model.Departments = await GetDepartmentsAsync();
                return View(model);
            }

            var course = await _context.Courses.FindAsync(id);
            if (course == null) return NotFound();

            course.Name = model.Name;
            course.Degree = model.Degree;
            course.MinDegree = model.MinDegree;
            course.DepartmentId = model.DepartmentId;

            _context.Update(course);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(ShowAll));
        }

        // 4. Delete (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course != null)
            {
                _context.Courses.Remove(course);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(ShowAll));
        }

        [HttpGet]
        public async Task<IActionResult> StudentResult(int studentId, int courseId)
        {
            var record = await _context.Set<StuCrsRes>()
                .Include(sc => sc.Student)
                .Include(sc => sc.Course)
                .FirstOrDefaultAsync(sc => sc.StudentId == studentId && sc.CourseId == courseId);

            if (record == null) return NotFound("No grade record found for this student in this course.");

            bool isPassed = record.Grade >= record.Course.MinDegree;

            var viewModel = new StudentCourseResultViewModel
            {
                StudentName = record.Student.Name,
                CourseName = record.Course.Name,
                Grade = record.Grade,
                ColorClass = isPassed ? "text-success fw-bold" : "text-danger fw-bold"
            };

            return View(viewModel);
        }

        private async Task<IEnumerable<SelectListItem>> GetDepartmentsAsync()
        {
            return await _context.Departments
                .Select(d => new SelectListItem
                {
                    Value = d.Id.ToString(),
                    Text = d.Name
                }).ToListAsync();
        }
    }
}