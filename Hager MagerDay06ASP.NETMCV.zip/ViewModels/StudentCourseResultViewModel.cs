﻿namespace Day02ASP.NETMCV.ViewModels
{
    public class StudentCourseResultViewModel
    {
        public string StudentName { get; set; }
        public string CourseName { get; set; }
        public decimal Grade { get; set; }
        public string ColorClass { get; set; }
    }
}