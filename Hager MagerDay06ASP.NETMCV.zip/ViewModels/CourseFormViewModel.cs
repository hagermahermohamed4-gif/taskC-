﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Day02ASP.NETMCV.ViewModels
{
    public class CourseFormViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Course name is required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Course name must be between 2 and 100 characters")]
        [Display(Name = "Course Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Total degree is required")]
        [Range(50, 200, ErrorMessage = "Total degree must be between 50 and 200")]
        [Display(Name = "Total Degree")]
        public int Degree { get; set; }

        [Required(ErrorMessage = "Minimum degree is required")]
        [Range(25, 100, ErrorMessage = "Minimum degree must be between 25 and 100")]
        [Display(Name = "Minimum Degree")]
        public int MinDegree { get; set; }

        [Required(ErrorMessage = "Please select a department")]
        [Display(Name = "Department")]
        public int DepartmentId { get; set; }

        public IEnumerable<SelectListItem> Departments { get; set; } = new List<SelectListItem>();
    }
}