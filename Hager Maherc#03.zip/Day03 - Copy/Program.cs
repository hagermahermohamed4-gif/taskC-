﻿using System;
using System.Text;

namespace Day03
{
    class Person
    {
        public string Name { get; set; }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // ================= Problem 1 =================
            Console.Write("P1 - Enter a number: ");
            string input1 = Console.ReadLine();

            try
            {
                int parsedResult = int.Parse(input1);
                int convertedResult = Convert.ToInt32(input1);

                Console.WriteLine($"Parsed: {parsedResult}, Converted: {convertedResult}");
            }
            catch (FormatException)
            {
                Console.WriteLine("P1 Error: Invalid integer format.");
            }
            catch (OverflowException)
            {
                Console.WriteLine("P1 Error: Number is out of Int32 range.");
            }


            // ================= Problem 2 =================
            Console.Write("P2 - Enter a number: ");
            string input2 = Console.ReadLine();

            if (int.TryParse(input2, out int number))
            {
                Console.WriteLine($"P2 Output: Valid Integer ({number})");
            }
            else
            {
                Console.WriteLine("P2 Error: Invalid input! Not an integer.");
            }


            // ================= Problem 3 =================
            object obj;

            obj = 10;
            Console.WriteLine($"P3 - int HashCode: {obj.GetHashCode()}");

            obj = "Hello";
            Console.WriteLine($"P3 - string HashCode: {obj.GetHashCode()}");

            obj = 10.5;
            Console.WriteLine($"P3 - double HashCode: {obj.GetHashCode()}");


            // ================= Problem 4 =================
            Person person1 = new Person { Name = "Hager" };
            Person person2 = person1;

            person1.Name = "Ahmed";

            Console.WriteLine($"P4 - person1.Name: {person1.Name}");
            Console.WriteLine($"P4 - person2.Name: {person2.Name}");


            // ================= Problem 5 =================
            string text = "Hello";
            Console.WriteLine($"P5 - HashCode before: {text.GetHashCode()}");

            text += " Hi Willy";
            Console.WriteLine($"P5 - HashCode after: {text.GetHashCode()}");


            // ================= Problem 6 =================
            StringBuilder sb6 = new StringBuilder("Hi Willy");
            Console.WriteLine($"P6 - StringBuilder HashCode before: {sb6.GetHashCode()}");

            sb6.Append(" - Welcome!");
            Console.WriteLine($"P6 - StringBuilder HashCode after: {sb6.GetHashCode()}");


            // ================= Problem 7 =================
            Console.Write("P7 - Enter input1: ");
            int inputVal1 = int.Parse(Console.ReadLine());

            Console.Write("P7 - Enter input2: ");
            int inputVal2 = int.Parse(Console.ReadLine());

            int sum = inputVal1 + inputVal2;

            // 1. Concatenation (+ operator)
            Console.WriteLine("Concatenation: Sum is " + inputVal1 + "+" + inputVal2 + " = " + sum);

            // 2. Composite formatting (string.Format)
            Console.WriteLine(string.Format("Composite Formatting: Sum is {0}+{1} = {2}", inputVal1, inputVal2, sum));

            // 3. String interpolation ($)
            Console.WriteLine($"String Interpolation: Sum is {inputVal1}+{inputVal2} = {sum}");


            // ================= Problem 8 =================
            StringBuilder sb8 = new StringBuilder("Hello World");

            sb8.Append(" - C#");
            sb8.Replace("World", "Willy");
            sb8.Insert(0, "Start: ");
            sb8.Remove(0, 7);

            Console.WriteLine($"P8 - Result: {sb8}");
        }
    }
}